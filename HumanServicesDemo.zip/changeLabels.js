function changeFilterLabels() {
    document.getElementsByTagName("option")[0].innerHTML = "All Facilities"
    document.getElementsByTagName("option")[1].innerHTML = "Counseling/Outpatient";
    document.getElementsByTagName("option")[2].innerHTML = "Crisis/Psychiatric Services";
    document.getElementsByTagName("option")[3].innerHTML = "Day Treatment";
    document.getElementsByTagName("option")[4].innerHTML = "Detoxification Services";
    document.getElementsByTagName("option")[5].innerHTML = "Long Term Treatment Services";
    document.getElementsByTagName("option")[6].innerHTML = "Medical";
    document.getElementsByTagName("option")[7].innerHTML = "National Self-Help Organizations";
    document.getElementsByTagName("option")[8].innerHTML = "Residential and Supportive Housing";
    document.getElementsByTagName("option")[9].innerHTML = "Short Term Inpatient Services";
    document.getElementsByTagName("option")[10].innerHTML ="Support Services, Helplines and Outreach";
};